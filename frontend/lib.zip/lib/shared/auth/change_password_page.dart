import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/app_color.dart';
import 'package:ta_mobile_disposisi_surat/shared/auth/reset_kata_sandi/input_email_page.dart';

// ── BASE URL ────────────────────────────────────────
// Ganti sesuai URL backend yang sudah di-deploy
const String _baseUrl = 'https://YOUR_DEPLOYED_BACKEND_URL/api';

class GantiKataSandiPage extends StatefulWidget {
  const GantiKataSandiPage({super.key});

  @override
  State<GantiKataSandiPage> createState() => _GantiKataSandiPageState();
}

class _GantiKataSandiPageState extends State<GantiKataSandiPage> {
  final TextEditingController _otpC = TextEditingController();
  final TextEditingController _newPassC = TextEditingController();
  final TextEditingController _confirmPassC = TextEditingController();

  bool _showOtp = false;
  bool _showNew = false;
  bool _showConfirm = false;

  bool _hasNumber = false;
  bool _min8Char = false;
  bool _hasUpperLower = false;
  bool _passwordMatch = false;

  // OTP state
  bool _otpSent = false;
  bool _isSendingOtp = false;
  bool _isSaving = false;

  // ── AMBIL TOKEN JWT ────────────────────────────────

  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // ── KIRIM OTP ──────────────────────────────────────

  Future<void> _sendOtp() async {
    setState(() => _isSendingOtp = true);

    try {
      final token = await _getToken();
      if (token == null) {
        _showSnackBar('Sesi berakhir, silakan login ulang', isError: true);
        return;
      }

      final response = await http.post(
        Uri.parse('$_baseUrl/profile/send-otp'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      final body = jsonDecode(response.body);

      if (response.statusCode == 200 && body['success'] == true) {
        setState(() => _otpSent = true);
        _showSnackBar('OTP telah dikirim ke email Anda');
      } else {
        _showSnackBar(body['message'] ?? 'Gagal mengirim OTP', isError: true);
      }
    } catch (e) {
      _showSnackBar('Gagal terhubung ke server', isError: true);
    } finally {
      setState(() => _isSendingOtp = false);
    }
  }

  // ── SIMPAN PASSWORD ────────────────────────────────

  Future<void> _changePassword() async {
    setState(() => _isSaving = true);

    try {
      final token = await _getToken();
      if (token == null) {
        _showSnackBar('Sesi berakhir, silakan login ulang', isError: true);
        return;
      }

      final response = await http.put(
        Uri.parse('$_baseUrl/profile/password'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'otp_code': _otpC.text.trim(),
          'new_password': _newPassC.text,
          'confirm_password': _confirmPassC.text,
        }),
      );

      final body = jsonDecode(response.body);

      if (response.statusCode == 200 && body['success'] == true) {
        _showSuccessDialog();
      } else {
        _showSnackBar(
          body['message'] ?? 'Gagal mengubah password',
          isError: true,
        );
      }
    } catch (e) {
      _showSnackBar('Gagal terhubung ke server', isError: true);
    } finally {
      setState(() => _isSaving = false);
    }
  }

  // ── SNACKBAR ───────────────────────────────────────

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red.shade600 : Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // ── VALIDATION ─────────────────────────────────────

  void _onNewChanged(String value) {
    setState(() {
      _hasNumber = RegExp(r'[0-9]').hasMatch(value);
      _min8Char = value.length >= 8;
      _hasUpperLower = RegExp(r'(?=.*[a-z])(?=.*[A-Z])').hasMatch(value);
      _passwordMatch = value == _confirmPassC.text;
    });
  }

  void _onConfirmChanged(String value) {
    setState(() {
      _passwordMatch = value == _newPassC.text;
    });
  }

  // ── TOGGLE ─────────────────────────────────────────

  void _toggleOtp() => setState(() => _showOtp = !_showOtp);
  void _toggleNew() => setState(() => _showNew = !_showNew);
  void _toggleConfirm() => setState(() => _showConfirm = !_showConfirm);

  // ── BUTTON VALID ───────────────────────────────────

  bool get _isValid =>
      _otpSent &&
      _otpC.text.trim().length == 6 &&
      _hasNumber &&
      _min8Char &&
      _hasUpperLower &&
      _passwordMatch;

  // ── SUCCESS DIALOG ─────────────────────────────────

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        contentPadding: const EdgeInsets.all(24),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(50),
              ),
              child: const Icon(
                Icons.check_circle_outline,
                color: AppColors.bluePrimary,
                size: 40,
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'Password Berhasil Diubah',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),

            const Text(
              'Kata sandi akun kamu berhasil diperbarui.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.black54,
                height: 1.5,
              ),
            ),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.bluePrimary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: const Text(
                  'OK',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── BUILD ──────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F2),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 16),

              // HEADER
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(
                      Icons.arrow_back_ios_new,
                      color: AppColors.bluePrimary,
                      size: 20,
                    ),
                  ),

                  const SizedBox(width: 8),

                  const Text(
                    'Ganti Kata Sandi',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppColors.bluePrimary,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Keamanan Akun',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          color: Colors.black87,
                        ),
                      ),

                      const SizedBox(height: 6),

                      const Text(
                        'Perbarui kata sandi Anda secara berkala untuk menjaga keamanan akun.',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.black45,
                          height: 1.5,
                        ),
                      ),

                      const SizedBox(height: 20),

                      // CARD
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // ── OTP SECTION ──────────────────────────────
                            _buildLabel('Kode OTP'),

                            const SizedBox(height: 4),

                            // Info teks
                            Text(
                              _otpSent
                                  ? 'OTP sudah dikirim ke email Anda. Berlaku 5 menit.'
                                  : 'Tekan "Kirim OTP" untuk mendapat kode verifikasi ke email Anda.',
                              style: TextStyle(
                                fontSize: 12,
                                color: _otpSent
                                    ? Colors.green.shade600
                                    : Colors.black45,
                                height: 1.4,
                              ),
                            ),

                            const SizedBox(height: 8),

                            // OTP field + tombol kirim OTP berdampingan
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: _buildField(
                                    controller: _otpC,
                                    hint: '6 digit kode OTP',
                                    isVisible: _showOtp,
                                    onChanged: (_) => setState(() {}),
                                    onToggle: _toggleOtp,
                                    keyboardType: TextInputType.number,
                                    maxLength: 6,
                                  ),
                                ),

                                const SizedBox(width: 10),

                                SizedBox(
                                  height: 50,
                                  child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: _isSendingOtp
                                          ? Colors.grey.shade300
                                          : AppColors.bluePrimary,
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 14,
                                      ),
                                    ),
                                    onPressed: _isSendingOtp ? null : _sendOtp,
                                    child: _isSendingOtp
                                        ? const SizedBox(
                                            width: 18,
                                            height: 18,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                              color: Colors.white,
                                            ),
                                          )
                                        : Text(
                                            _otpSent
                                                ? 'Kirim\nUlang'
                                                : 'Kirim\nOTP',
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white,
                                            ),
                                          ),
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 20),

                            // ── PASSWORD BARU ────────────────────────────
                            _buildLabel('Kata sandi baru'),

                            const SizedBox(height: 8),

                            _buildField(
                              controller: _newPassC,
                              hint: 'Masukkan kata sandi baru',
                              isVisible: _showNew,
                              onChanged: _onNewChanged,
                              onToggle: _toggleNew,
                            ),

                            if (_newPassC.text.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: Column(
                                  children: [
                                    _buildValidationRow(
                                      'Mengandung minimal satu angka',
                                      _hasNumber,
                                    ),
                                    _buildValidationRow(
                                      'Terdiri dari minimal 8 karakter',
                                      _min8Char,
                                    ),
                                    _buildValidationRow(
                                      'Mengandung huruf besar & huruf kecil',
                                      _hasUpperLower,
                                    ),
                                  ],
                                ),
                              ),

                            const SizedBox(height: 20),

                            // ── KONFIRMASI PASSWORD ──────────────────────
                            _buildLabel('Konfirmasi kata sandi baru'),

                            const SizedBox(height: 8),

                            _buildField(
                              controller: _confirmPassC,
                              hint: 'Ulangi kata sandi baru',
                              isVisible: _showConfirm,
                              onChanged: _onConfirmChanged,
                              onToggle: _toggleConfirm,
                            ),

                            if (_confirmPassC.text.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: _buildValidationRow(
                                  _passwordMatch
                                      ? 'Konfirmasi password cocok'
                                      : 'Konfirmasi password tidak cocok',
                                  _passwordMatch,
                                ),
                              ),

                            const SizedBox(height: 8),

                            // LUPA PASSWORD
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                style: TextButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                  minimumSize: Size.zero,
                                  tapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          const ForgotPasswordPage(),
                                    ),
                                  );
                                },
                                child: const Text(
                                  'Lupa kata sandi?',
                                  style: TextStyle(
                                    color: AppColors.bluePrimary,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),

              // BUTTON SIMPAN
              Padding(
                padding: const EdgeInsets.only(bottom: 20, top: 4),
                child: SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: _isValid && !_isSaving
                          ? AppColors.bluePrimary
                          : Colors.grey.shade400,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    onPressed: (_isValid && !_isSaving)
                        ? _changePassword
                        : null,
                    child: _isSaving
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          )
                        : const Text(
                            'Simpan Perubahan',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── LABEL ──────────────────────────────────────────

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: Colors.black45,
        letterSpacing: 0.8,
      ),
    );
  }

  // ── FIELD ──────────────────────────────────────────

  Widget _buildField({
    required TextEditingController controller,
    required String hint,
    required bool isVisible,
    required VoidCallback onToggle,
    required Function(String) onChanged,
    TextInputType keyboardType = TextInputType.text,
    int? maxLength,
  }) {
    return TextField(
      controller: controller,
      enableInteractiveSelection: true,
      obscureText: !isVisible,
      enableSuggestions: false,
      autocorrect: false,
      keyboardType: keyboardType,
      maxLength: maxLength,
      onChanged: onChanged,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: Colors.black87,
      ),
      decoration: InputDecoration(
        hintText: hint,
        counterText: '',
        hintStyle: TextStyle(
          color: AppColors.hinttext,
          fontSize: 14,
          fontWeight: FontWeight.w400,
        ),
        filled: true,
        fillColor: const Color(0xFFF3F4F7),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
            color: AppColors.bluePrimary,
            width: 1.4,
          ),
        ),
        suffixIcon: IconButton(
          onPressed: onToggle,
          icon: Icon(
            isVisible
                ? Icons.visibility_outlined
                : Icons.visibility_off_outlined,
            color: Colors.grey,
            size: 20,
          ),
        ),
      ),
    );
  }

  // ── VALIDATION ROW ─────────────────────────────────

  Widget _buildValidationRow(String text, bool isValid) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Icon(
            isValid ? Icons.check_circle : Icons.error_outline,
            color: isValid ? Colors.green : Colors.red,
            size: 16,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              text,
              style: TextStyle(
                color: isValid ? Colors.green : Colors.red,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
