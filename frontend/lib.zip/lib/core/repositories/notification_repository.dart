import 'package:dio/dio.dart';
import 'package:ta_mobile_disposisi_surat/core/network/api_client.dart';

class NotificationRepository {
  final _dio = ApiClient.dio;

  /// GET /api/notifications
  /// Response: { success, data: [ { id, judul, pesan, jenis, is_read, created_at, ... } ] }
  Future<List<Map<String, dynamic>>> getList() async {
    try {
      final res = await _dio.get('/api/notifications');
      final List list = res.data['data'] as List? ?? [];

      if (list.isEmpty) return [];

      return list.map((item) {
        return {
          'id': item['id'] ?? 0,
          'title': item['judul'] ?? '',
          'desc': item['pesan'] ?? '',
          'jenis': item['jenis'] ?? '',
          'isRead': item['is_read'] ?? false,
          'createdAt':
              DateTime.tryParse(item['created_at'] ?? '') ?? DateTime.now(),
        };
      }).toList();
    } on DioException catch (e) {
      throw Exception('Gagal memuat notifikasi: ${e.message}');
    }
  }

  /// GET /api/notifications/unread-count
  /// Response: { success, data: { count: 5 } }
  Future<int> getUnreadCount() async {
    try {
      final res = await _dio.get('/api/notifications/unread-count');
      return (res.data['data']?['count'] as int?) ?? 0;
    } on DioException {
      return 0;
    }
  }

  /// PUT /api/notifications/:id/read
  Future<void> markAsRead(int id) async {
    try {
      await _dio.put('/api/notifications/$id/read');
    } on DioException catch (e) {
      throw Exception('Gagal menandai notifikasi: ${e.message}');
    }
  }

  /// PUT /api/notifications/read-all
  Future<void> markAllRead() async {
    try {
      await _dio.put('/api/notifications/read-all');
    } on DioException catch (e) {
      throw Exception('Gagal menandai semua notifikasi: ${e.message}');
    }
  }
}
