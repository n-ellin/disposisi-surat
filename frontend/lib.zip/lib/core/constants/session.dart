// lib/core/constants/session.dart
import 'package:ta_mobile_disposisi_surat/core/constants/role.dart';

class Session {
  static String nama = '';
  static String email = '';
  static String jabatan = '';
  static Role role = Role.user;

  static bool get isWaka => role == Role.waka;
}