import 'package:ta_mobile_disposisi_surat/core/constants/role.dart';

class SuratDummy {
  // ── Surat Masuk ───────────────────────────────────────────────────────────

  static const Map<String, dynamic> suratMasukDisetujui = {
    'id': 'SM001',
    'jenisSurat': 'Surat Masuk',
    'tanggal': '03 Jun 2025',
    'status': 'disetujui',
    'diteruskanKe': 'Waka Kurikulum',
    'catatan': 'Harap ditindaklanjuti sesuai prosedur yang berlaku.',
    'data': {
      'Perihal': 'Undangan Rapat Koordinasi',
      'Dari': 'Dinas Pendidikan Kota',
      'No. Surat': '421/123/2025',
      'Tanggal Surat': '01 Jun 2025',
    },
  };

  static const Map<String, dynamic> suratMasukDitolak = {
    'id': 'SM002',
    'jenisSurat': 'Surat Masuk',
    'tanggal': '02 Jun 2025',
    'status': 'ditolak',
    'diteruskanKe': '',
    'catatan': 'Tidak sesuai dengan agenda sekolah.',
    'data': {
      'Perihal': 'Penawaran Kerjasama',
      'Dari': 'CV Maju Bersama',
      'No. Surat': '001/CVB/2025',
      'Tanggal Surat': '01 Jun 2025',
    },
  };

  static const Map<String, dynamic> suratMasukDiproses = {
    'id': 'SM003',
    'jenisSurat': 'Surat Masuk',
    'tanggal': '01 Jun 2025',
    'status': 'diproses',
    'diteruskanKe': '',
    'catatan': '',
    'data': {
      'Perihal': 'Pemberitahuan Lomba OSN',
      'Dari': 'Kemendikbud',
      'No. Surat': '523/D/2025',
      'Tanggal Surat': '30 Mei 2025',
    },
  };

  static const Map<String, dynamic> suratMasukMenunggu = {
    'id': 'SM004',
    'jenisSurat': 'Surat Masuk',
    'tanggal': '05 Jun 2025',
    'status': 'menunggu',
    'diteruskanKe': '',
    'catatan': '',
    'data': {
      'Perihal': 'Permohonan Data Siswa',
      'Dari': 'BPS Kota',
      'No. Surat': '300/BPS/VI/2025',
      'Tanggal Surat': '04 Jun 2025',
    },
  };

  // ── Surat Keluar ──────────────────────────────────────────────────────────

  static const Map<String, dynamic> suratKeluarDisetujui = {
    'id': 'SK001',
    'jenisSurat': 'Surat Keluar',
    'tanggal': '04 Jun 2025',
    'status': 'disetujui',
    'diteruskanKe': '',
    'catatan': 'Silakan dikirimkan segera.',
    'data': {
      'Perihal': 'Permohonan Izin Kegiatan',
      'Dari': 'SMA Negeri 1',
      'No. Surat': '422/045/2025',
      'Tanggal Surat': '04 Jun 2025',
    },
  };

  static const Map<String, dynamic> suratKeluarMenunggu = {
    'id': 'SK002',
    'jenisSurat': 'Surat Keluar',
    'tanggal': '05 Jun 2025',
    'status': 'menunggu',
    'diteruskanKe': '',
    'catatan': '',
    'data': {
      'Perihal': 'Undangan Rapat Internal',
      'Dari': 'SMA Negeri 1',
      'No. Surat': '423/046/2025',
      'Tanggal Surat': '05 Jun 2025',
    },
  };

  static const Map<String, dynamic> suratKeluarDitolak = {
    'id': 'SK003',
    'jenisSurat': 'Surat Keluar',
    'tanggal': '03 Jun 2025',
    'status': 'ditolak',
    'diteruskanKe': '',
    'catatan': 'Format surat tidak sesuai, harap direvisi.',
    'data': {
      'Perihal': 'Pengajuan Dana Kegiatan',
      'Dari': 'SMA Negeri 1',
      'No. Surat': '420/044/2025',
      'Tanggal Surat': '02 Jun 2025',
    },
  };

  // ── Koleksi per kebutuhan testing ─────────────────────────────────────────

  /// Semua surat — untuk testing list panjang / scroll
  static List<Map<String, dynamic>> get all => [
    suratMasukDisetujui,
    suratMasukDitolak,
    suratMasukDiproses,
    suratMasukMenunggu,
    suratKeluarDisetujui,
    suratKeluarMenunggu,
    suratKeluarDitolak,
  ];

  /// Hanya surat masuk
  static List<Map<String, dynamic>> get masuk => [
    suratMasukDisetujui,
    suratMasukDitolak,
    suratMasukDiproses,
    suratMasukMenunggu,
  ];

  /// Hanya surat keluar
  static List<Map<String, dynamic>> get keluar => [
    suratKeluarDisetujui,
    suratKeluarMenunggu,
    suratKeluarDitolak,
  ];

  /// Surat yang sudah selesai diproses (disetujui / ditolak) — untuk testing riwayat
  static List<Map<String, dynamic>> get riwayat => all
      .where((s) => s['status'] == 'disetujui' || s['status'] == 'ditolak')
      .toList();

  /// Surat masuk yang diteruskan ke role tertentu — untuk testing MenuUser / waka
  static List<Map<String, dynamic>> suratUntukRole(Role role) {
    final jabatan = switch (role) {
      Role.waka => 'Waka Kurikulum',
      Role.user => 'Kapro',
      _         => '',
    };
    if (jabatan.isEmpty) return [];
    return masuk
        .where((s) => s['diteruskanKe'] == jabatan)
        .toList();
  }
}