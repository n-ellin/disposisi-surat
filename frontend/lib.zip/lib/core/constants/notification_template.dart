import 'package:flutter/material.dart';

enum NotifType {
  // TU / Pegawai
  suratMasukDitolak,
  suratMasukDiterima,
  suratKeluarDitolak,
  suratKeluarDiterima,
  suratMasukDiteruskan,
  // Kepsek
  pengajuanSuratKeluar,
  pengajuanDisposisiSuratMasuk,
  // Waka
  suratMasukUntukWaka,
  suratDikonfirmasiPenerima,
  // User/Guru
  suratMasukUntukUser,
}

class NotifTemplate {
  final String title;
  final String desc;
  final Color color;

  const NotifTemplate({
    required this.title,
    required this.desc,
    required this.color,
  });
}

const Map<NotifType, NotifTemplate> notifTemplates = {
  NotifType.suratMasukDitolak: NotifTemplate(
    title: 'Surat Masuk Ditolak',
    desc:
        'Surat masuk telah ditolak Kepala Sekolah. Silakan periksa kembali dan tindak lanjuti.',
    color: Colors.red,
  ),
  NotifType.suratMasukDiterima: NotifTemplate(
    title: 'Surat Masuk Diterima',
    desc:
        'Surat masuk telah diterima Kepala Sekolah. Silakan lanjutkan proses.',
    color: Colors.green,
  ),
  NotifType.suratKeluarDitolak: NotifTemplate(
    title: 'Surat Keluar Ditolak',
    desc:
        'Surat keluar ditolak Kepala Sekolah. Periksa kembali dan tindak lanjuti.',
    color: Colors.red,
  ),
  NotifType.suratKeluarDiterima: NotifTemplate(
    title: 'Surat Keluar Diterima',
    desc:
        'Surat keluar telah diterima Kepala Sekolah. Silakan lanjutkan proses.',
    color: Colors.green,
  ),
  NotifType.suratMasukDiteruskan: NotifTemplate(
    title: 'Surat Masuk Diteruskan',
    desc: 'Waka telah meneruskan surat kepada penerima terkait.',
    color: Colors.blue,
  ),
  NotifType.pengajuanSuratKeluar: NotifTemplate(
    title: 'Pemberitahuan Pengajuan Surat Keluar',
    desc:
        'Terdapat pengajuan surat keluar yang memerlukan peninjauan dari Anda.',
    color: Colors.orange,
  ),
  NotifType.pengajuanDisposisiSuratMasuk: NotifTemplate(
    title: 'Pemberitahuan Pengajuan Disposisi Surat Masuk',
    desc:
        'Terdapat pengajuan disposisi surat masuk yang memerlukan persetujuan Anda.',
    color: Colors.blue,
  ),
  NotifType.suratMasukUntukWaka: NotifTemplate(
    title: 'Pemberitahuan Surat Masuk',
    desc:
        'Anda menerima surat masuk. Silakan periksa detail surat untuk informasi lebih lanjut.',
    color: Colors.blue,
  ),
  NotifType.suratDikonfirmasiPenerima: NotifTemplate(
    title: 'Surat Telah Dikonfirmasi',
    desc: 'Penerima disposisi telah mengonfirmasi surat yang Anda teruskan.',
    color: Colors.green,
  ),
  NotifType.suratMasukUntukUser: NotifTemplate(
    title: 'Pemberitahuan Surat Masuk',
    desc:
        'Anda menerima surat masuk baru. Silakan periksa detail surat untuk informasi lebih lanjut.',
    color: Colors.blue,
  ),
};

// Mapping string dari backend → NotifType
const Map<String, NotifType> notifTypeMap = {
  'surat_masuk_ditolak': NotifType.suratMasukDitolak,
  'surat_masuk_diterima': NotifType.suratMasukDiterima,
  'surat_keluar_ditolak': NotifType.suratKeluarDitolak,
  'surat_keluar_diterima': NotifType.suratKeluarDiterima,
  'surat_masuk_diteruskan': NotifType.suratMasukDiteruskan,
  'pengajuan_surat_keluar': NotifType.pengajuanSuratKeluar,
  'pengajuan_disposisi_surat_masuk': NotifType.pengajuanDisposisiSuratMasuk,
  'surat_masuk_waka': NotifType.suratMasukUntukWaka,
  'surat_dikonfirmasi_penerima': NotifType.suratDikonfirmasiPenerima,
  'surat_masuk_user': NotifType.suratMasukUntukUser,
};

// ⭐ TAMBAH: Helper function untuk safety
NotifTemplate getNotifTemplate(NotifType type) {
  return notifTemplates[type] ?? notifTemplates[NotifType.suratMasukDiterima]!;
}
