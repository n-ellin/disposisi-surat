import 'package:flutter/material.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/app_color.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/role.dart';
import 'package:ta_mobile_disposisi_surat/data/repositories/surat_repository.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/search_bar.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/surat_card.dart';
import 'package:ta_mobile_disposisi_surat/features/kepsek/pages/disposisi_suratmasuk.dart';
import 'package:ta_mobile_disposisi_surat/features/kepsek/pages/pengajuan_suratkeluar.dart';

class KepsekDashboardPage extends StatefulWidget {
  final String jenisSurat;
  const KepsekDashboardPage({super.key, required this.jenisSurat});

  @override
  State<KepsekDashboardPage> createState() => _KepsekDashboardPageState();
}

class _KepsekDashboardPageState extends State<KepsekDashboardPage> {
  final _repo = SuratRepository();

  String _searchQuery = '';
  List<Map<String, dynamic>> _suratList = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchSurat();
  }

  /// Ambil data dari API sesuai jenis surat.
  Future<void> _fetchSurat() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final isMasuk = widget.jenisSurat == 'Surat Masuk';
      final raw = isMasuk
          ? await _repo.getSuratMasukList()
          : await _repo.getSuratKeluarList();

      setState(() {
        _suratList = raw.map((item) => _mapToCard(item, isMasuk)).toList();
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal memuat data. Periksa koneksi.';
        _isLoading = false;
      });
    }
  }

  /// Konversi response API ke format yang dibutuhkan SuratCard.
  String _formatTanggal(String isoDate) {
    try {
      final dt = DateTime.parse(isoDate);
      const months = [
        '',
        'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember',
      ];
      return '${dt.day} ${months[dt.month]} ${dt.year}';
    } catch (_) {
      return isoDate;
    }
  }

  Map<String, dynamic> _mapToCard(dynamic item, bool isMasuk) {
    final tanggalRaw = item['tanggal_surat'] ?? '';
    final tanggal = tanggalRaw.isNotEmpty
        ? _formatTanggal(tanggalRaw.toString())
        : '-';

    return {
      'id': item['id'],
      'jenisSurat': widget.jenisSurat,
      'tanggal': tanggal,
      'status': item['status_verifikasi'] ?? '',
      'raw': item,
      'data': {
        'No Surat': item['no_surat'] ?? '-',
        'Tanggal': tanggal,
        'Perihal': isMasuk
            ? (item['perihal_surat'] ?? '-')
            : (item['perihal'] ?? '-'),
        'Dari': isMasuk ? (item['asal_surat'] ?? '-') : (item['tujuan'] ?? '-'),
      },
    };
  }

  /// Filter berdasarkan search query.
  List<Map<String, dynamic>> get _filteredSurat {
    if (_searchQuery.isEmpty) return _suratList;

    final query = _searchQuery.toLowerCase();
    return _suratList.where((s) {
      final dari = (s['data']?['Dari'] ?? '').toString().toLowerCase();
      final perihal = (s['data']?['Perihal'] ?? '').toString().toLowerCase();
      return dari.contains(query) || perihal.contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final w = size.width;
    final h = size.height;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: const Color(0xFFF2F2F2),
        surfaceTintColor: Colors.transparent,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: w * 0.04),
            child: SizedBox(
              width: w * 0.1,
              height: w * 0.1,
              child: ClipOval(
                child: Image.asset(
                  'assets/images/logosmk.jpg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(w * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Disposisi Surat',
              style: TextStyle(
                fontSize: (w * 0.055).clamp(18.0, 24.0),
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: h * 0.015),

            SearchBarInput(
              onChanged: (value) => setState(() => _searchQuery = value),
            ),

            SizedBox(height: h * 0.015),

            Expanded(child: _buildBody(w, h)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(double w, double h) {
    // Loading state
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    // Error state
    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_errorMessage!, style: const TextStyle(color: Colors.red)),
            SizedBox(height: h * 0.02),
            ElevatedButton(
              onPressed: _fetchSurat,
              child: const Text('Coba Lagi'),
            ),
          ],
        ),
      );
    }

    // Empty state
    if (_filteredSurat.isEmpty) {
      return Center(
        child: Text(
          'Tidak ada surat ditemukan.',
          style: TextStyle(color: Colors.grey.shade500),
        ),
      );
    }

    // Data list
    return RefreshIndicator(
      onRefresh: _fetchSurat,
      child: ListView.builder(
        padding: EdgeInsets.only(bottom: h * 0.03),
        itemCount: _filteredSurat.length,
        itemBuilder: (context, index) {
          final surat = _filteredSurat[index];

          return Padding(
            padding: EdgeInsets.only(bottom: h * 0.01),
            child: SuratCard(
              jenisSurat: surat['jenisSurat'],
              tanggal: surat['tanggal'],
              status: surat['status'],
              data: Map<String, String>.from(surat['data']),
              role: CardRole.kepsek,
              type: CardType.menu,
              onDetail: () {
                final isMasuk = surat['jenisSurat'] == 'Surat Masuk';
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => isMasuk
                        ? InputSuratMasuk(surat: surat)
                        : InputSuratKeluar(),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
