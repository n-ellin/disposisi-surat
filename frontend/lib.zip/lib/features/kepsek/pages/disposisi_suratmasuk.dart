import 'package:flutter/material.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/app_color.dart';
import 'package:ta_mobile_disposisi_surat/core/utils/full-images-viewer.dart';

class InputSuratMasuk extends StatefulWidget {
  final Map<String, dynamic> surat;

  const InputSuratMasuk({super.key, required this.surat});

  @override
  State<InputSuratMasuk> createState() => _InputSuratMasukState();
}

class _InputSuratMasukState extends State<InputSuratMasuk> {
  String? _selectedStatus;
  final TextEditingController catatanController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _catatanKey = GlobalKey();
  String? catatanError;

  bool get isApproved => _selectedStatus == 'terima';
  bool get isRejected => _selectedStatus == 'tolak';

  List<String> get attachmentUrls =>
      List<String>.from(widget.surat['lampiran'] ?? []);

  Map<String, dynamic> get suratData => widget.surat['data'] ?? {};

  @override
  void initState() {
    super.initState();
    catatanController.addListener(() {
      if (catatanError != null && catatanController.text.isNotEmpty) {
        setState(() => catatanError = null);
      }
    });
  }

  bool _validate() {
    catatanError = null;

    if (_selectedStatus == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text("Pilih status terlebih dahulu."),
          backgroundColor: Colors.red.shade400,
        ),
      );
      return false;
    }

    if (catatanController.text.trim().isEmpty) {
      catatanError = "Catatan wajib diisi.";
      setState(() {});
      _scrollToField(_catatanKey);
      return false;
    }

    setState(() {});
    return true;
  }

  void _scrollToField(GlobalKey key) {
    final context = key.currentContext;
    if (context != null) {
      Scrollable.ensureVisible(
        context,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
        alignment: 0.2,
      );
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    catatanController.dispose();
    super.dispose();
  }

  void _onKirimPressed() {
    final isValid = _validate();
    if (!isValid) return;
    _showConfirmDialog(context);
  }

  void _showConfirmDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.send_rounded, color: AppColors.bluePrimary),
            SizedBox(width: 8),
            Text("Kirim Disposisi"),
          ],
        ),
        content: const Text("Apakah Anda yakin ingin mengirim disposisi ini?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Batal", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.bluePrimary,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            onPressed: () {
              Navigator.pop(context);
              _submitDisposisi();
            },
            child: const Text("Yakin"),
          ),
        ],
      ),
    );
  }

  void _submitDisposisi() {
    final payload = {
      'status': _selectedStatus,
      'catatan': catatanController.text.trim(),
    };

    debugPrint('Payload disposisi: $payload');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final w = size.width;
    final h = size.height;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(w * 0.05, h * 0.025, w * 0.05, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: const Icon(
                      Icons.arrow_back_ios_new,
                      color: AppColors.bluePrimary,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: w * 0.02),
                  const Expanded(
                    child: Text(
                      "Detail Surat Masuk",
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.bluePrimary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: h * 0.025),
            Expanded(
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _detailCard(context),
                    const SizedBox(height: 20),
                    const Text(
                      "Status",
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                _selectedStatus = 'terima';
                                catatanError = null;
                              });
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: _selectedStatus == 'terima'
                                    ? AppColors.bluePrimary
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: _selectedStatus == 'terima'
                                      ? AppColors.bluePrimary
                                      : Colors.grey.shade300,
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    _selectedStatus == 'terima'
                                        ? Icons.radio_button_checked
                                        : Icons.radio_button_off,
                                    size: 16,
                                    color: _selectedStatus == 'terima'
                                        ? Colors.white
                                        : Colors.grey.shade400,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    "Terima",
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: _selectedStatus == 'terima'
                                          ? Colors.white
                                          : Colors.black87,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                _selectedStatus = 'tolak';
                                catatanError = null;
                              });
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              decoration: BoxDecoration(
                                color: _selectedStatus == 'tolak'
                                    ? AppColors.bluePrimary
                                    : Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: _selectedStatus == 'tolak'
                                      ? AppColors.bluePrimary
                                      : Colors.grey.shade300,
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    _selectedStatus == 'tolak'
                                        ? Icons.radio_button_checked
                                        : Icons.radio_button_off,
                                    size: 16,
                                    color: _selectedStatus == 'tolak'
                                        ? Colors.white
                                        : Colors.grey.shade400,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    "Tolak",
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: _selectedStatus == 'tolak'
                                          ? Colors.white
                                          : Colors.black87,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (_selectedStatus != null) ...[
                      const SizedBox(height: 20),
                      _sectionCard(  // ✅ FIX: hapus "widget"
                        title: "Form Disposisi",
                        children: [
                          Container(
                            key: _catatanKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildLabel("Catatan *"),
                                _textField(
                                  hint: "Masukkan catatan...",
                                  controller: catatanController,
                                ),
                                if (catatanError != null)
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      left: 4,
                                      bottom: 8,
                                    ),
                                    child: Text(
                                      catatanError!,
                                      style: const TextStyle(
                                        color: Colors.red,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 20),
                    if (_selectedStatus != null)
                      Align(
                        alignment: Alignment.centerRight,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.bluePrimary,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 30,
                              vertical: 10,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _onKirimPressed,
                          child: const Text("Kirim"),
                        ),
                      ),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _detailItem(
            Icons.description_outlined,
            "Nomor Surat",
            suratData['Nomor Surat'] ?? '-',
          ),
          _detailItem(
            Icons.calendar_today_outlined,
            "Tanggal",
            widget.surat['tanggal'] ?? '-',
          ),
          _detailItem(
            Icons.person_outline,
            "Pengirim",
            suratData['Dari'] ?? '-',
          ),
          _detailItem(Icons.notes, "Perihal", suratData['Perihal'] ?? '-'),
          const SizedBox(height: 4),
          Text(
            "Lampiran",
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          if (attachmentUrls.isEmpty)
            Text(
              "Tidak ada lampiran",
              style: TextStyle(color: Colors.grey.shade400, fontSize: 14),
            )
          else
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => FullScreenImageViewer(
                      imageUrls: attachmentUrls,
                      initialIndex: 0,
                    ),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.attach_file_rounded,
                      color: AppColors.bluePrimary,
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      "${attachmentUrls.length} File Lampiran",
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.remove_red_eye_outlined,
                      color: Colors.grey.shade500,
                      size: 16,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _detailItem(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 24,
            color: Colors.grey.shade500,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade500,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({required String title, required List<Widget> children}) {  // ✅ FIX: List<Widget>
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            blurRadius: 10,
            offset: const Offset(0, 4),
            color: Colors.black.withOpacity(0.05),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 18,
                decoration: BoxDecoration(
                  color: AppColors.bluePrimary,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          ...children,
        ],
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
      ),
    );
  }

  Widget _textField({required String hint, TextEditingController? controller}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: controller,
        maxLines: 4,
        cursorColor: Colors.black,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: AppColors.hinttext, fontSize: 14),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 14,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: AppColors.bluePrimary,
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}