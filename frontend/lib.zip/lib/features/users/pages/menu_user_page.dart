import 'package:flutter/material.dart';

import '../../../data/repositories/surat_repository.dart';

import 'package:ta_mobile_disposisi_surat/core/constants/notification_template.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/app_color.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/role.dart';
import 'package:ta_mobile_disposisi_surat/core/helpers/navigation_helper.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/session.dart';

import 'package:ta_mobile_disposisi_surat/features/users/pages/detail_surat_user.dart';

import 'package:ta_mobile_disposisi_surat/shared/widgets/custom_navbar.dart';

import 'package:ta_mobile_disposisi_surat/features/notifications/notification_page.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/search_bar.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/surat_card.dart';

class MenuUser extends StatefulWidget {
  final String nama;
  final String email;
  final String jabatan;
  final Role role;

  const MenuUser({
    super.key,
    required this.nama,
    required this.email,
    required this.jabatan,
    required this.role,
  });

  @override
  State<MenuUser> createState() => _MenuUserState();
}

class _MenuUserState extends State<MenuUser> {
  /// Menyimpan kata kunci pencarian surat.
  String searchQuery = '';

  /// Menyimpan daftar notifikasi user.
  late List<Map<String, dynamic>> notifications;

  // ✅ API & data
  final _suratRepo = SuratRepository();
  List<Map<String, dynamic>> _suratMasukList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    notifications = List.from(notifUser);
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final masuk = await _suratRepo.getSuratMasukList();
      if (!mounted) return;
      setState(() {
        _suratMasukList = List<Map<String, dynamic>>.from(masuk);
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal load data: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// Mengambil daftar surat masuk sesuai peran user saat ini.
  List<Map<String, dynamic>> get suratMasukList => _suratMasukList;

  /// Memfilter surat berdasarkan kata kunci pencarian pada field utama.
  List<Map<String, dynamic>> get filteredSurat {
    if (searchQuery.isEmpty) {
      return suratMasukList;
    }

    return suratMasukList.where((surat) {
      final query = searchQuery.toLowerCase();

      final jenis = surat["jenisSurat"].toString().toLowerCase();

      final tanggal = surat["tanggal"].toString().toLowerCase();

      final status = surat["status"].toString().toLowerCase();

      final dari = (surat["data"]?["Dari"] ?? '').toString().toLowerCase();

      final perihal = (surat["data"]?["Perihal"] ?? '')
          .toString()
          .toLowerCase();

      return jenis.contains(query) ||
          tanggal.contains(query) ||
          status.contains(query) ||
          dari.contains(query) ||
          perihal.contains(query);
    }).toList();
  }

  /// Menghitung jumlah notifikasi yang belum dibaca.
  int get notifCount => notifications.where((n) => n['isRead'] == false).length;

  /// Membuka halaman notifikasi lalu menandai semua notifikasi sebagai dibaca.
  Future<void> _openNotification() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            NotificationPage(role: widget.role, notifications: notifications),
      ),
    );

    setState(() {
      for (var notif in notifications) {
        notif['isRead'] = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // ✅ LOADING STATE
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final size = MediaQuery.of(context).size;

    final w = size.width;
    final h = size.height;

    final bottomPadding = MediaQuery.of(context).padding.bottom;

    double rf(double size) {
      return (w * (size / 375)).clamp(size * 0.85, size * 1.2);
    }

    return Scaffold(
      backgroundColor: AppColors.bg,

      /// Navigasi bawah untuk perpindahan antar halaman utama user.
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 12,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: CustomNavbar(
              role: widget.role,
              currentIndex: 0,
              onTap: (index) {
                handleNavbarTap(
                  context,
                  index,
                  widget.role,
                  widget.nama,
                  widget.email,
                  widget.jabatan,
                );
              },
            ),
          ),

          ColoredBox(
            color: AppColors.bg,
            child: SizedBox(height: bottomPadding, width: double.infinity),
          ),
        ],
      ),

      /// Konten utama halaman menu disposisi user.
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: w * 0.06),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: h * 0.03),

                  /// Header berisi logo dan akses cepat notifikasi.
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.asset(
                        "assets/images/logosmk.jpg",
                        width: w * 0.1,
                        height: w * 0.1,
                        fit: BoxFit.cover,
                      ),

                      GestureDetector(
                        onTap: _openNotification,
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Icon(
                              Icons.notifications_none,
                              size: w * 0.075,
                              color: AppColors.bluePrimary,
                            ),

                            /// Badge jumlah notifikasi belum dibaca.
                            if (notifCount > 0)
                              Positioned(
                                right: -(w * 0.008),
                                top: -(w * 0.008),
                                child: Container(
                                  padding: EdgeInsets.all(w * 0.008),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFE53935),
                                    shape: BoxShape.circle,
                                  ),
                                  constraints: BoxConstraints(
                                    minWidth: w * 0.045,
                                    minHeight: w * 0.045,
                                  ),
                                  child: Center(
                                    child: Text(
                                      notifCount > 9
                                          ? '9+'
                                          : notifCount.toString(),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: rf(9),
                                        fontWeight: FontWeight.bold,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: h * 0.02),

                  /// Judul halaman disposisi surat.
                  Text(
                    "Disposisi Surat",
                    style: TextStyle(
                      fontSize: rf(22),
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),

                  SizedBox(height: h * 0.025),

                  /// Kolom pencarian surat disposisi.
                  SearchBarInput(
                    hintText: 'Cari surat...',
                    onChanged: (value) {
                      setState(() {
                        searchQuery = value;
                      });
                    },
                  ),

                  SizedBox(height: h * 0.012),

                  /// Daftar surat hasil filter pencarian.
                  Expanded(
                    child: RefreshIndicator(
                      onRefresh: _loadData, // ✅ PULL TO REFRESH
                      child: ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        padding: EdgeInsets.only(bottom: h * 0.015),
                        itemCount: filteredSurat.length,
                        itemBuilder: (context, index) {
                          final surat = filteredSurat[index];

                          return Padding(
                            padding: EdgeInsets.only(bottom: h * 0.002),
                            child: SuratCard(
                              jenisSurat: surat["jenisSurat"].toString(),

                              tanggal: surat["tanggal"].toString(),

                              status: surat["status"]?.toString(),

                              role: CardRole.Users,

                              type: CardType.menu,

                              data: Map<String, String>.from(surat["data"]),

                              diteruskanKe: surat["diteruskanKe"]?.toString(),

                              onDetail: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        DetailSuratUsers(surat: surat),
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}