import 'package:flutter/material.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/filterdatebar.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/surat_card.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/custom_navbar.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/search_bar.dart';
import 'package:ta_mobile_disposisi_surat/shared/widgets/filter_date.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/role.dart';
import 'package:ta_mobile_disposisi_surat/core/helpers/navigation_helper.dart';
import 'package:ta_mobile_disposisi_surat/core/constants/app_color.dart';
import 'package:ta_mobile_disposisi_surat/core/repositories/surat_masuk_repository.dart';
import 'package:ta_mobile_disposisi_surat/features/users/pages/user/detail_surat_user.dart';
import 'package:ta_mobile_disposisi_surat/features/users/pages/waka/detail_surat_waka.dart';

class HistoryUsersPage extends StatefulWidget {
  final Role role;
  final String nama;
  final String email;
  final String jabatan;

  const HistoryUsersPage({
    super.key,
    required this.role,
    required this.nama,
    required this.email,
    required this.jabatan,
  });

  @override
  State<HistoryUsersPage> createState() => _HistoryUsersPageState();
}

class _HistoryUsersPageState extends State<HistoryUsersPage> {
  final _suratMasukRepo = SuratMasukRepository();

  List<Map<String, dynamic>> _historyList = [];
  bool _isLoading = true;
  String? _error;
  String _searchQuery = '';

  String _statusFilter = 'semua';
  DateTime? _startDate;
  DateTime? _endDate;
  String? _activeChip;
  String _dateFilterLabel = 'Pilih Tanggal';

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  // FIX: kirim date ke BE, bukan hanya filter client-side
  Future<void> _loadHistory() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      // Konversi ke ISO date string "YYYY-MM-DD" untuk dikirim ke BE
      final dateFrom = _startDate?.toIso8601String().substring(0, 10);
      final dateTo = _endDate?.toIso8601String().substring(0, 10);

      final result = await _suratMasukRepo.getHistory(
        dateFrom: dateFrom,
        dateTo: dateTo,
      );

      if (!mounted) return;
      setState(() {
        _historyList = result.map((s) => s.toMenuMap()).toList();
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Gagal memuat riwayat. Coba lagi.';
        _historyList = [];
        _isLoading = false;
      });
    }
  }

  // Filter client-side: search + status + tanggal (fallback setelah BE filter)
  List<Map<String, dynamic>> get _filtered {
    return _historyList.where((s) {
      final data = s['data'] as Map<String, dynamic>? ?? {};
      final q = _searchQuery.toLowerCase();

      final matchSearch =
          _searchQuery.isEmpty ||
          (data['Perihal'] ?? '').toString().toLowerCase().contains(q) ||
          (data['Dari'] ?? '').toString().toLowerCase().contains(q) ||
          (data['Nomor Surat'] ?? '').toString().toLowerCase().contains(q);

      final matchStatus =
          _statusFilter == 'semua' ||
          (s['status']?.toString().toLowerCase() == _statusFilter);

      // Tanggal fallback — data dari BE sudah difilter, ini hanya pengaman UI
      bool matchDate = true;
      if (_startDate != null && _endDate != null) {
        final raw = s['tanggal']?.toString() ?? '';
        // toMenuMap() format: "d MMM yyyy" — parse dulu ke DateTime
        final suratDate = _parseTanggal(raw);
        if (suratDate.year > 1970) {
          final start = DateTime(
            _startDate!.year,
            _startDate!.month,
            _startDate!.day,
          );
          final end = DateTime(
            _endDate!.year,
            _endDate!.month,
            _endDate!.day,
            23,
            59,
            59,
          );
          matchDate = !suratDate.isBefore(start) && !suratDate.isAfter(end);
        }
      }

      return matchSearch && matchStatus && matchDate;
    }).toList();
  }

  DateTime _parseTanggal(String tanggal) {
    const bulan = {
      'jan': 1,
      'feb': 2,
      'mar': 3,
      'apr': 4,
      'mei': 5,
      'jun': 6,
      'jul': 7,
      'agu': 8,
      'sep': 9,
      'okt': 10,
      'nov': 11,
      'des': 12,
    };
    try {
      final parts = tanggal.toLowerCase().trim().split(' ');
      return DateTime(
        int.parse(parts[2]),
        bulan[parts[1]] ?? 1,
        int.parse(parts[0]),
      );
    } catch (_) {
      return DateTime(1970);
    }
  }

  // FIX: re-fetch setelah pilih date filter supaya BE ikut difilter
  void _showDateFilter() async {
    final result = await DateRangeFilterBottomSheet.show(
      context: context,
      initialStartDate: _startDate,
      initialEndDate: _endDate,
      initialChip: _activeChip ?? 'semua',
    );
    if (result == null) return;
    setState(() {
      _startDate = result.startDate;
      _endDate = result.endDate;
      _activeChip = result.activeChip;
      _dateFilterLabel = result.dateFilterLabel;
    });
    _loadHistory(); // re-fetch dengan date baru
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    double rf(double size) => (w * (size / 375)).clamp(size * 0.9, size * 1.15);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(
                top: h * 0.025,
                left: w * 0.05,
                right: w * 0.05,
                bottom: h * 0.015,
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Icon(
                      Icons.arrow_back_ios_new,
                      color: AppColors.bluePrimary,
                      size: w * 0.055,
                    ),
                  ),
                  SizedBox(width: w * 0.02),
                  Text(
                    'Riwayat',
                    style: TextStyle(
                      fontSize: w * 0.048,
                      fontWeight: FontWeight.bold,
                      color: AppColors.bluePrimary,
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: EdgeInsets.fromLTRB(w * 0.05, 0, w * 0.05, 0),
              child: Column(
                children: [
                  SearchBarInput(
                    onChanged: (val) => setState(() => _searchQuery = val),
                  ),
                  SizedBox(height: h * 0.014),
                  Wrap(
                    spacing: w * 0.02,
                    runSpacing: h * 0.01,
                    children: [
                      SizedBox(
                        width: (w - (w * 0.12)) / 3,
                        child: _filterChip('semua', rf),
                      ),
                      SizedBox(
                        width: (w - (w * 0.12)) / 3,
                        child: _filterChip('disetujui', rf),
                      ),
                      SizedBox(
                        width: (w - (w * 0.12)) / 3,
                        child: _filterChip('ditolak', rf),
                      ),
                    ],
                  ),
                  SizedBox(height: h * 0.012),
                  DateFilterBar(
                    label: _dateFilterLabel,
                    onTap: _showDateFilter,
                  ),
                  SizedBox(height: h * 0.016),
                ],
              ),
            ),

            Expanded(
              child: _isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: AppColors.bluePrimary,
                      ),
                    )
                  : _error != null
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: Colors.red.shade300,
                            size: 48,
                          ),
                          SizedBox(height: h * 0.01),
                          Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                          SizedBox(height: h * 0.01),
                          ElevatedButton(
                            onPressed: _loadHistory,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.bluePrimary,
                              foregroundColor: Colors.white,
                              elevation: 0,
                            ),
                            child: const Text('Coba lagi'),
                          ),
                        ],
                      ),
                    )
                  : _filtered.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.inbox_outlined,
                            size: 56,
                            color: Colors.grey.shade300,
                          ),
                          SizedBox(height: h * 0.015),
                          Text(
                            'Belum ada riwayat surat',
                            style: TextStyle(
                              color: Colors.grey.shade500,
                              fontSize: w * 0.04,
                            ),
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadHistory,
                      color: AppColors.bluePrimary,
                      child: ListView.builder(
                        padding: EdgeInsets.symmetric(
                          horizontal: w * 0.05,
                          vertical: h * 0.01,
                        ),
                        itemCount: _filtered.length,
                        itemBuilder: (context, index) {
                          final surat = _filtered[index];
                          return Padding(
                            padding: EdgeInsets.only(bottom: h * 0.012),
                            child: SuratCard(
                              jenisSurat:
                                  surat['jenisSurat']?.toString() ??
                                  'Surat Masuk',
                              tanggal: surat['tanggal']?.toString() ?? '-',
                              data: Map<String, String>.from(
                                surat['data'] ?? {},
                              ),
                              role: widget.role == Role.waka
                                  ? CardRole.waka
                                  : CardRole.Users,
                              type: CardType.history,
                              status: surat['status']?.toString() ?? '-',
                              onDetail: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => widget.role == Role.waka
                                        ? DetailSuratWaka(surat: surat)
                                        : DetailSuratUsers(surat: surat),
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: w * 0.03,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: CustomNavbar(
              role: widget.role,
              currentIndex: 1,
              onTap: (index) => handleNavbarTap(
                context,
                index,
                widget.role,
                widget.nama,
                widget.email,
                widget.jabatan,
              ),
            ),
          ),
          ColoredBox(
            color: AppColors.bg,
            child: SizedBox(height: bottomPadding, width: double.infinity),
          ),
        ],
      ),
    );
  }

  Widget _filterChip(String label, double Function(double) rf) {
    final w = MediaQuery.of(context).size.width;
    final isActive = _statusFilter == label;

    Color activeColor;
    switch (label) {
      case 'disetujui':
        activeColor = const Color(0xFF3F9142);
        break;
      case 'ditolak':
        activeColor = const Color(0xFFB63A3A);
        break;
      default:
        activeColor = AppColors.bluePrimary;
    }

    final displayLabel = label[0].toUpperCase() + label.substring(1);

    return GestureDetector(
      onTap: () => setState(() => _statusFilter = label),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: w * 0.03, vertical: 7),
        decoration: BoxDecoration(
          color: isActive ? activeColor : Colors.white,
          borderRadius: BorderRadius.circular(w * 0.05),
          border: Border.all(
            color: isActive ? activeColor : const Color(0xFFD1D5DB),
            width: 1.2,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: activeColor.withOpacity(0.25),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ]
              : [],
        ),
        child: Text(
          displayLabel,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: rf(13),
            fontWeight: FontWeight.w600,
            color: isActive ? Colors.white : const Color(0xFF6B7280),
          ),
        ),
      ),
    );
  }
}
